CREATE TABLE Testes (
elementos INT NOT NULL,
ordem VARCHAR(20) NOT NULL,
dados VARCHAR(20) NOT NULL,
tempo INT NOT NULL,
algoritmo VARCHAR(20) NOT NULL
);
